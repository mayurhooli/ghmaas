package com.senseitout.jaikisan;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.TextView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {
    TextView sun, dew, temp, hum, soil;
AsyncHttpResponseHandler handler;
    Runnable r1 = new Runnable() {
        @Override
        public void run() {
while (1==1) {
    try {
        AsyncHttpClient client = new AsyncHttpClient();
        client.get("https://greenhouseiot.mybluemix.net/output.htm", handler);
        Thread.sleep(5000, 0);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
}
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sun = (TextView) findViewById(R.id.text_sun);
        dew = (TextView) findViewById(R.id.text_dew);
        temp = (TextView) findViewById(R.id.text_temp);
        hum = (TextView) findViewById(R.id.text_hum);
        soil = (TextView) findViewById(R.id.text_soil);
        handler= new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, byte[] bytes) {
                String str=new String(bytes);
                String[] nums=str.split("\n");
                temp.setText(Integer.parseInt(nums[0]) + "\u00B0 C");
                hum.setText(Integer.parseInt(nums[1]) + " %");
                dew.setText(Integer.parseInt(nums[2])==1?"on":"off");
                sun.setText(Integer.parseInt(nums[3]) + " lux");
                soil.setText(Integer.parseInt(nums[4]) + " %");
            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {

            }
        };

        Thread t = new Thread (r1);
        t.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
